To install this module:
Copy both files in this folder, and move them into the NeverwinterNights/NWN/modules folder.
Then run the game, click on new game, other modules, and find The Retribution of Scenegaul.